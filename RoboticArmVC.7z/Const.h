/*
 * Const.h
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 *
 *      Constantes et llien vars la biblioth�que SERVO
 */

#ifndef CONST_H_
#define CONST_H_

//d�finie le compte maximum, minimum et l'amplitude du timer
#define MAX_COUNTER 2000
#define MIN_COUNTER 25
#define AMPLITUDE 165

#include <msp430g2553.h>
#include "Servo.h"



#endif

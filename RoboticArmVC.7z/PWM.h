/*
 * PWM.h
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 *
 *      Ensemble de fonctions permettant la gestion de la PWM logicielle
 */

#ifndef PWM_H_
#define PWM_H_

#include "Const.h"

//valeur maximum de la pwm d'un servo
#define MAX_SERVO_VAL 16.0

//Configuration du timer (pour �tre plus pr�cis) 8MHz / 8
#define TIMER_SETUP TASSEL_2 | ID_3 | MC_1 |TAIE

//Configuration du compteur du timer Tick toutes les 1�s -> 10 pour faire un compte en plus sur Counter
#define TIMER_COUNT 9;


//compteur d'�tat pour la cr�ation de la PWM logicielle
extern unsigned int Counter;

//Fonction d'initialisation de la PWM logicielle
void InitPWM();

//fonction de misa a jour de la PWM (appel�e � chaque int�ruption cr��e par le timer)
void MAJOutState();

//fonction d'organisation des PWMs pour augmenter la vitesse de calcul
void OrderOutput();

//remet les �tats de toutes les PWM � 1
void ResetPWM ();

#endif

/*
 * main.c
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 */

#include "PWM.h"
#include "Input.h"
#include "Communication.h"


//setup de l'interruption pour la connection UART
// Protocole : r�ponse envoy�e � la r�ception d'un message. 8bit de donn�e pour Rx et Tx
//
//  1   2    3
//  XXX XXXX X
//
//  1 : num�ro su servo asservi
//  2 : valeur � atteindre (entre 0 et 16)
//  3 : Bit de check -> somme des bits de la section 1 et 2 tronqu�e � 1 bit

#pragma vector=USCIAB0RX_VECTOR
__interrupt void USCI0RX_ISR(void)
{
    //si le message re�u est d�cod�
    if (Decode() == 1)
    {
        //r�organise les sorties
        OrderOutput();
    }

    /* Flag RESET */
    TA0CTL &= ~TAIFG;
}

//setup de l'interruption pour la mise � jour des PWMs
#pragma vector=TIMER0_A0_VECTOR
__interrupt void Timer_A0_ISR(void)
{
    //incr�ment du compteur des PWMs
    Counter++;

    //Mise � jour de l'�tat des PWMs
    MAJOutState();

    //reset de l'int�ruption
    TA0CTL &= ~TAIFG;
}

//Programme principal
void main(void)
{
    //D�sactivation du timer watchdog
	WDTCTL = WDTPW | WDTHOLD;	// stop watchdog timer

    //initialisation des composants du programme
	InitServo();
 	InitInput();
	InitPWM();
	InitComm();


    //autorisation des int�ruptions
    __enable_interrupt();

    //d�marrage de la boucle pricipale
	while(1)
	{
	    //Mise � jour de l'�tat des capteurs logiciels -> pour des raisons d'optimisation, cette fonction reste dans la boucle principale (elle n'est pas prioritaire sur les int�ruptions)
	    UpdateInputForce();
	}
}

/*
 * PWM.c
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 */

#include "PWM.h"

//compteur d'�tat pour la cr�ation de la PWM logicielle
unsigned int Counter;

//Ports de sortie des PWS
char PortsO[NBSERVO] = {BIT0, BIT1, BIT2, BIT3, BIT4, BIT5};

//S�quence de mise � z�ro rapide des PWMs
//   - Le choix de cete impl�mentation vient du fait que si on connait la s�quence d'allumage des PWM
//     on peu la jouer comme une partition du musique sans necessiter des calculs inutiles
char PortSequence[NBSERVO] = {0,1,2,3,4,5};

//compte de la s�quence
char OutputCount = 0;

//Fonction d'initialisation de la PWM logicielle
void InitPWM()
{
    //initialisation de l'horloge du timer
   DCOCTL  = 0;
   BCSCTL1 = CALBC1_8MHZ;
   DCOCTL  = CALDCO_8MHZ;

    //Configuration du timer
    TA0CCR0 = TIMER_COUNT;
    TA0CTL = TIMER_SETUP;

    TA0CCTL0 = CCIE;

    //Initialisation des sorties des PWMs
    unsigned char i;

    for(i = 0; i<NBSERVO; i++)
    {
        //mise en route des pins de sortie
        P2SEL &= ~(PortsO[i]);
        P2SEL2 &= ~(PortsO[i]);
        //mode sortie des pins
        P2DIR  |= (PortsO[i]);
        P2OUT &= ~(PortsO[i]);

        //assignation des ports
        ServoArray[i].PortOutput = PortsO[i];
    }

    //remise � z�ro des �tats des PWMs -> d�marrage
    ResetPWM ();
}

//remet les �tats de toutes les PWM � 1
void ResetPWM ()
{
    unsigned int i;

    //remise � 1 des bits de sortie -> en une fois c'est plus rapide
    P2OUT |= BIT0 | BIT1 | BIT2 | BIT3 | BIT4 | BIT5;

    //pour chaque servos
    for (i=0 ; i<NBSERVO ; i++)
    {
        //remise � 1 de son �tat
        ServoArray[i].State = 1;

    }
    //remise � z�ro du compteur d'�tat
    Counter = 0;
}

//fonction d'organisation des PWMs pour augmenter la vitesse de calcul
void OrderOutput()
{

    unsigned int i=0;
    unsigned char Tag = 0;

    //ici nous cherchons � r�oragniser la s�quence � lire en fonction de la valeur PWMVal de chaque servos
    //nous utiliseron la methode du tri � bulle avec optimisation de sortie de boucle

    //tant que le compte d'inversement innutile de deux servos moteurs dans la s�quence n'est pas �gal � 6-1
    while(Tag < NBSERVO-1)
    {
        //si ce n'est pas le dernier de la liste
        if (i<NBSERVO-1)
        {
            //si les valeurs des PWM de deux servos cons�cutifs ne sont pas dans l'ordre croissant
            if (ServoArray[PortSequence[i]].PWMVal > ServoArray[PortSequence[i+1]].PWMVal)
            {
                //inverser les servos
                int c = PortSequence[i];
                PortSequence[i] = PortSequence[i+1];
                PortSequence[i+1] = c;
            }
            else
            {
                //Compte d'inversement innutile +1
                Tag++;
            }
            //incr�mente l'indice
            i++;
        }
        else
        {
            //remets � jour l'indice d'inversement innutile et de place dans la liste
            i=0;
            Tag = 0;
        }
    }

}


//fonction de misa a jour de la PWM (appel�e � chaque int�ruption cr��e par le timer)
void MAJOutState()
{
    //si le compteur n'a pas d�pass� le compte max de tick -> 25ms
    if (Counter < MAX_COUNTER)
    {
        //si la s�quence est en cours -> optimisation pour ne pas avoir a lire la suite si s�quence termin�e
       if (OutputCount < NBSERVO)
       {
           //si le compteur d�passe la valeur sp�cifi�e de la PWM
           if (Counter > ServoArray[PortSequence[OutputCount]].PWMVal)
           {
               //�teint la sortie
               P2OUT &= ~ServoArray[PortSequence[OutputCount]].PortOutput;
               ServoArray[PortSequence[OutputCount]].State = 0;
               OutputCount++;
           }
       }

    }
    else
    {
        //sinon remet � r�ro la PMW et la s�quence des PWM
        OutputCount = 0;
        ResetPWM ();
    }

}



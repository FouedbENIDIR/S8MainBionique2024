/*
 * Input.h
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 *
 *      Ensemble de fonctions permettant la misa � jour des valeurs capteurs
 */

#ifndef INPUT_H_
#define INPUT_H_

#include "Const.h"

//initialise les entr�es capteur
void InitInput();

//mets a jour les valeurs capteurs
void UpdateInputForce();

#endif

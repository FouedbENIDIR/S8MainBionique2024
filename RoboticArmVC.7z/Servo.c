/*
 * Servo.c
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 */

#include "Servo.h"


Servo ServoArray[NBSERVO];//variable globale contenant toutes les informations des servos


//fonction d'initialisation des servos
void InitServo()
{

    unsigned char i;
    unsigned char j;

    for (i = 0;  i < NBSERVO; i++)
    {
        ServoArray[i].PWMVal = MIN_COUNTER;

        //initialisation des tableaux de force
        for (j = 0;  j < TAILLE_MOYENNE; j++)
        {
            ServoArray[i].TabForce[j] = 0;
        }

        ServoArray[i].PtrForce = 0;

    }

}

//calcul de la moyenne du tableau des valeurs capteurs d'un servo
//  --in &TabForce
char ComuteMoyenne(char* Tab)
{
    float summ = 0;
    unsigned char j;

    for (j = 0;  j < TAILLE_MOYENNE; j++)
    {
        //somme de tous les echantions de force
        summ = Tab[j] + summ;

    }

    //mise de la valeur sur 4 bits
    summ = 15.0 * summ;
    summ = summ/TAILLE_MOYENNE;
    char test = 0;
    test = (char)summ;
    return test;
}



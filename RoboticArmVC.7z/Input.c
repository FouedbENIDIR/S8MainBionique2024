/*
 * Input.c
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 */

#include "Input.h"

//Ports d'entr�e des capteurs
char PortsI[6] = {BIT0, BIT3, BIT4, BIT5, BIT6, BIT7};

//initialise les entr�es capteur
void InitInput()
{
    unsigned char i;

    //Initialisation des ports d'entr�e
    for(i = 0; i<NBSERVO; i++)
    {
        //mise en route des pins de sortie
        P1SEL &= ~(PortsI[i]);
        P1SEL2 &= ~(PortsI[i]);

        P1DIR  &= ~(PortsI[i]);
        P1OUT &= ~(PortsI[i]);

        ServoArray[i].PortInput = PortsI[i];
    }

}

//mets a jour les valeurs capteurs
void UpdateInputForce()
{
    unsigned char i;
    //pour chaque servo
    for(i = 0; i<NBSERVO; i++)
    {

        char PortBuff = ServoArray[i].PortInput;
        char ret = ((P1IN & PortBuff) == PortBuff);

        //Mets � jour la valeur du tableau
        ServoArray[i].TabForce[ServoArray[i].PtrForce] = ret;

        //avance le compteur du tableau force ou remets le � zero
        if (ServoArray[i].PtrForce < TAILLE_MOYENNE)
        {
            ServoArray[i].PtrForce++;
        }
        else
        {
            ServoArray[i].PtrForce = 0;
        }

    }
}

/*
 * Communication.h
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 *
 *      Ensemble de valeurs et de fonctions pour la gestion de la communication UART
 */

#ifndef COMMUNICATION_H_
#define COMMUNICATION_H_

#include "Const.h"

//d�finition des interfaces de connection uart
#define RXD                  BIT1
#define TXD                  BIT2

//d�finition des messages de r�ponse du syst�me au messages en entr�e
#define MESSAGE_OK           (char)0b00000000
#define MESSAGE_ERROR_SERVO  (char)0b11100001
#define MESSAGE_ERROR_VAL    (char)0b11100010
#define MESSAGE_ERROR_CHECK  (char)0b11100100

//d�finition des masques du message
#define VALUE_MASK           (char)0b00001111
#define CHECK_MASK           (char)0b00000001

//Initialisation de la communication uart entre msp et port s�rie
void InitComm(void);

//D�finition des fonctions de lecture et �criture dans l'uart (octet par octet dans notre cas)
char uart_getchar(void);
void uart_putchar(char c);

//Cr�ation du message � envoyer si message OK
void SendMessage( char Nb);

//v�rification de la validit� du message
char checkMsg(char MsgToCheck);

//calcule de la valeur PWM en fonction de la valeur recue
int PercentToPwmVal(char input);

//d�code le message recu
char Decode();

#endif

/*
 * Communication.c
 *
 *  Created on: 15 mai 2024
 *      Author: cavard
 */
#include "Communication.h"



//Initialisation de la communication uart entre msp et port s�rie
void InitComm(void)
{
    //selection des pin des entr�ess osrtie
    P1SEL  = RXD | TXD;
    P1SEL2 = RXD | TXD;

    //mise � zero de UCA0 en mode reset
    UCA0CTL1 = UCSWRST;

    //configuration du BaudRate
    // CLK = 16 MHz et Baud Rate = 9600
    UCA0CTL1 |= UCSSEL_2;
    UCA0BR0  = 0x41;    // UCAxBR0 (LSB)
    UCA0BR1  = 0x03;    // UCAxBR1 (MSB)
    UCA0MCTL = 0x92;    // UCBRSx

    //sortie du mode reset de UCA0
    UCA0CTL1 &= ~UCSWRST;

    //Allumage des int�ruptions
    UC0IE /* (= IE2) */ |= UCA0RXIE;
}

//D�finition des fonctions de lecture et �criture dans l'uart (octet par octet dans notre cas)
char uart_getchar(void)
{

    char chr = 255;

    //si un caract�re est lisible (a priori oui parce que c'est une int�ruption mais on ne sait jamais)
    if (IFG2 & UCA0RXIFG) {
        //si oui copie la valeur dans un buffer
        chr = UCA0RXBUF;
    }

    //retourne le buffer
    return chr;
}

void uart_putchar(char c)
{
    //attends que le mps soit pr�t � l'envoie
    while (!(IFG2 & UCA0TXIFG));

    //transmet l'octet
    UCA0TXBUF = c;

}

//d�code le message recu
char Decode()
{

    char ret = 0;
    const char ReceivedChar = uart_getchar();

    //r�cup�ration du message
    char Check = (char)(ReceivedChar & CHECK_MASK);

    //r�cup�ration des inforamtions dans le message
    char SernoNb = ReceivedChar >> 5;
    char ValueServo = ReceivedChar  >> 1 ;
    ValueServo = ValueServo & VALUE_MASK;

    //si le num�ro du servo est correct
    if ( SernoNb < NBSERVO)
    {
        //si la valeur sero est correcte (plutot pour des probl�mes interne ou pour une impl�mentation future avec plus de crans)
        if ( ValueServo <= 15)
        {
            //si le bit de check est bon
            if (Check == checkMsg(ReceivedChar))
            {
                //mise � jour de la valeur
                int buff = PercentToPwmVal(ValueServo);
                ServoArray[SernoNb].PWMVal = buff;
                SendMessage(SernoNb);

                //si bon message retourne 1
                ret = 1;
            }
            else
            {
                //envoie du message d'erreur valeur
                SendMessage(MESSAGE_ERROR_CHECK);
            }
        }
        else
        {
            //envoie du message d'erreur valeur
            SendMessage(MESSAGE_ERROR_VAL);
        }
    }
    else
    {
        //envoie du message d'erreur servo
        SendMessage(MESSAGE_ERROR_SERVO);
    }
    //si mauvais message retourne 0
    return ret;
}

//calcule de la valeur PWM en fonction de la valeur recue
int PercentToPwmVal(char input)
{
    // Calcul complet (( X / 15.0 ) * AMPLITUDE ) + MIN_COUNTER
    float Percent = (float)input;
    Percent = Percent/15.0;
    Percent = Percent *(float)( AMPLITUDE );
    Percent = MIN_COUNTER + Percent;

    int test = (int)Percent;

    return test;
}

//v�rification de la validit� du message
char checkMsg(char MsgToCheck)
{
    unsigned char i = 0;
    unsigned char ret = 0;

    //on enl�ve le premier bit de check
    char Buff = MsgToCheck >> 1;

    //on somme les 7 autres
    for(i=0;i<7;i++)
    {
        char a = Buff >> i;
        ret = ret +  (a & CHECK_MASK);
    }

    //on renvoie la valeur masqu�e sur le premier bit
    return ret & CHECK_MASK;
}

//Cr�ation du message � envoyer si message OK
void SendMessage(char Nb)
{
   char MsgToSend = 0;

   //Si le message semble erron�
   if (Nb == MESSAGE_ERROR_SERVO || Nb == MESSAGE_ERROR_VAL || Nb == MESSAGE_ERROR_CHECK )
   {
       //renvoie du message par l'UART
       uart_putchar(Nb);
   }
   else
   {
       //Sinon composition de la r�ponse
       //r�cup�ration de la valeur moyenne du tableau de force
       char Moy = ComuteMoyenne(ServoArray[Nb].TabForce);

       //Encapsulation par le num�ro du servo ...
       MsgToSend = Nb << 5 | Moy << 1;
       //.. et le bit de check
       MsgToSend = MsgToSend | checkMsg(MsgToSend);
       // envoie du message
       uart_putchar(MsgToSend);
   }

}

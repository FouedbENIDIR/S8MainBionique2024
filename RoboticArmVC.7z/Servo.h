/*
 * Servo.h
 *
 *  Created on: 19 avr. 2024
 *      Author: cavard
 *
 *      Ensemble de valeurs et de fonction pour la gestion des Servomoteurs
 */

#ifndef SERVO_H_
#define SERVO_H_

//Taille du tableau de la moyenne logicielle
#define TAILLE_MOYENNE 30

//Nombre de servo asservis
#define NBSERVO 6

#include "Const.h"

//structure d�finissant des param�tres d'un servo
typedef struct{
    char PortInput;//port capteur
    char PortOutput;//port de commande
    char State;//�tat allum� ouu �teint
    char PWMVal;//la valeur du compteur a laquelle la sortiee est mise � z�ro
    char PtrForce;//valeur du compteur vers le tableau des valeurs capteur
    char TabForce[TAILLE_MOYENNE];//tableau des valeurs capteurs

}Servo;

//variable globale contenant toutes les informations des servos
extern Servo ServoArray[NBSERVO];

//fonction d'initialisation des servos
void InitServo();

//calcul de la moyenne du tableau des valeurs capteurs d'un servo --in &TabForce
char ComuteMoyenne(char* Tab);


#endif /* SERVO_H_ */

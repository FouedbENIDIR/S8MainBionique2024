"""
OpenSignals Lab Streaming Layer - Receiving data from a specific host computer
------------------------------------------------------------------------------

Example script to show how to receive a (multi-)channel signal stream from OpenSignals (r)evolution from a specific host
using the Lab Streaming Layer (LSL) and the host name.

Notes
-----
..  This example is based on the official LSL 'ReceiveData.py' example which can be found here:
    https://github.com/labstreaminglayer/liblsl-Python/blob/d95f40e878111620600f7d6dc6b45b62ac961776/pylsl/examples/ReceiveData.py
..  Visit the official Lab Streaming Layer repository for the latest news and versions of the LSL:
    https://github.com/sccn/labstreaminglayer
..  You can download OpenSignals (r)evolution here:
    https://www.biosignalsplux.com/en/software

Last Update
-----------
..  04.01.2019

"""
# Imports
from pylsl import StreamInlet, resolve_stream

# Define the name of the host streaming the sensor data
hostname = "HOSTNAME"

# Resolve stream
print("# Looking for an available OpenSignals stream from the specified host...")
os_stream = resolve_stream("hostname", hostname)

# Create an inlet to receive signal samples from the stream
inlet = StreamInlet(os_stream[0])

# Get information about the stream
stream_info = inlet.info()

# Get individual attributes
stream_name = stream_info.name()
stream_mac = stream_info.type()
stream_host = stream_info.hostname()
stream_n_channels = stream_info.channel_count()

# Store sensor channel info & units in dictionary
stream_channels = dict()
channels = stream_info.desc().child("channels").child("channel")

# Loop through all available channels
for i in range(stream_n_channels - 1):
    # Get the channel number (e.g. 1)
    channel = i + 1

    # Get the channel type (e.g. ECG)
    sensor = channels.child_value("sensor")

    # Get the channel unit (e.g. mV)
    unit = channels.child_value("unit")

    # Store the information in the stream_channels dictionary
    stream_channels.update({channel: [sensor, unit]})
    channels = channels.next_sibling()

while True:
    # Receive samples
    samples, timestamp = inlet.pull_sample()
    print(timestamp, samples)
